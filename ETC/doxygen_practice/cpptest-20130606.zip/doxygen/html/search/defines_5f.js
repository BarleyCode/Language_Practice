var searchData=
[
  ['_5fatl_5fcstring_5fexplicit_5fconstructors',['_ATL_CSTRING_EXPLICIT_CONSTRUCTORS',['../stdafx_8h.html#a137e19a46f145129447af81af06def9f',1,'stdafx.h']]],
  ['_5fwin32_5fie',['_WIN32_IE',['../targetver_8h.html#ad4562ce705fe4682e63dc8f1ea9dd344',1,'targetver.h']]],
  ['_5fwin32_5fwindows',['_WIN32_WINDOWS',['../targetver_8h.html#a074ca98c073d899c62fc6629918186c8',1,'targetver.h']]],
  ['_5fwin32_5fwinnt',['_WIN32_WINNT',['../targetver_8h.html#ac50762666aa00bd3a4308158510f1748',1,'targetver.h']]]
];
