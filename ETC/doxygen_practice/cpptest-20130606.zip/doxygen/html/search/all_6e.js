var searchData=
[
  ['ndevicetype',['nDeviceType',['../class_sales_promotion_info.html#ac3ea3cc75c565565138ad4ae6d90ab11',1,'SalesPromotionInfo']]],
  ['norders',['nOrders',['../class_sales_promotion_info.html#aee18f4f18be36ae51a401b3a7698537b',1,'SalesPromotionInfo']]]
];
