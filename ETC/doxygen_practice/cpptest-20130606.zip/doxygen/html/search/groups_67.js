var searchData=
[
  ['global_5ffunc',['GLOBAL_FUNC',['../group___g_l_o_b_a_l___f_u_n_c.html',1,'']]]
];
