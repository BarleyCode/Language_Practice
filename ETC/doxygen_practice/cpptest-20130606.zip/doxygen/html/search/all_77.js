var searchData=
[
  ['winver',['WINVER',['../targetver_8h.html#a966cd377b9f3fdeb1432460c33352af1',1,'targetver.h']]]
];
