var searchData=
[
  ['szcontent',['szContent',['../class_sales_promotion_info.html#a674863d1ca17959463a22eec222a85b3',1,'SalesPromotionInfo']]],
  ['szenddate',['szEndDate',['../class_sales_promotion_info.html#a2549bcdd00f6fe21d454b82cb5dc69b8',1,'SalesPromotionInfo']]],
  ['szimgurl',['szImgUrl',['../class_sales_promotion_info.html#a1d411818f905ee98ebaa64bb36de402b',1,'SalesPromotionInfo']]],
  ['szmoveto',['szMoveTo',['../class_sales_promotion_info.html#a283b8adca4e95e7d90d5436dd7cfd2d8',1,'SalesPromotionInfo']]],
  ['szsptype',['szSPType',['../class_sales_promotion_info.html#a8989d6a2be058336ae7d7cd8f4da63d7',1,'SalesPromotionInfo']]],
  ['szstartdate',['szStartDate',['../class_sales_promotion_info.html#a67fe361de4b0518deec21a4155fa5f3a',1,'SalesPromotionInfo']]],
  ['sztitle',['szTitle',['../class_sales_promotion_info.html#a7868a8c2e07229d0d087077da7405131',1,'SalesPromotionInfo']]]
];
