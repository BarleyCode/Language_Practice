var searchData=
[
  ['virtual_20_ea_b8_b0_eb_8a_a5_ec_9d_84_20_ed_85_8c_ec_8a_a4_ed_8a_b8_20_ed_95_98_ea_b8_b0_20_ec_9c_84_ed_95_9c_20_ed_95_a8_ec_88_98_eb_93_a4',['virtual 기능을 테스트 하기 위한 함수들',['../group___v_i_r_t_u_a_l___t_e_s_t.html',1,'']]]
];
